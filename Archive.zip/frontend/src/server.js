export const server = "https://shop-o-1.onrender.com/api/v2";
